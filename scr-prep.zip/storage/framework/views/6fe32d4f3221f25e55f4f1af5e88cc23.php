<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>SCR</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  
  <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,300italic&subset=latin' rel='stylesheet' type='text/css'>
  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="css/style.css" rel="stylesheet">

</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="index.html">SCR</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link scrollto" href="#services">Services</a></li>
          
          
          
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
          
          <?php if(auth()->guard()->guest()): ?>
          <li><a class="nav-link scrollto" href="<?php echo e(url('admin/login')); ?>">Admin Login</a></li>
          <li><a class="getstarted scrollto" href="<?php echo e(url('login')); ?>">Login</a></li>
      <?php endif; ?>
      <?php if(auth()->guard()->check()): ?>
          <?php if(Auth::user()->is_admin): ?>
              <li><a class="nav-link scrollto" href="<?php echo e(url('admin/dashboard')); ?>">Admin Dashboard</a></li>
          <?php else: ?>
              <li><a class="nav-link scrollto" href="<?php echo e(url('home')); ?>">User Dashboard</a></li>
          <?php endif; ?>
          <li><a class="getstarted scrollto" href="<?php echo e(url('logout')); ?>">Logout</a></li>
      <?php endif; ?>
      
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container position-relative" data-aos="fade-up" data-aos-delay="100">
      <div class="row justify-content-center">
        <div class="col-xl-7 col-lg-9 text-center">
         <?php if(auth()->guard()->check()): ?>
         <h2 class=" text-capitalize">Welcome <?php echo e(Auth::user()->first_name); ?>, to</h2>
         <?php endif; ?>
          <h1>Substainability and Climate Risk (SCR)</h1>
          <h2>SCR Preparation Module</h2>
        </div>
      </div>
      <?php if(auth()->guard()->guest()): ?>
      <div class="text-center">
        <a href=<?php echo e(url('login')); ?> class="btn-get-started scrollto">Get Started</a>
      </div>
      <?php endif; ?>
      <?php if(auth()->guard()->check()): ?>
      <div class="text-center">
        <a href=<?php echo e(url('home')); ?> class="btn-get-started scrollto">Get Started</a>
      </div>
  <?php endif; ?>
     

      
        

      
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>About Us</h2>
          <p>Aim to provide the solution for individuals seeking to navigate the challenges posed by SCR</p>
        </div>

        <div class="row content">
          <div class="col-lg-12">
            <p>
              Our main goal is to offer a complete solution for individuals who wants to understand and deal with the challanges
              brought by climate change. Providing various resources like revision notes and test series along with mock 
              tests and video solutions. And in test series providing the detailed feedback of 
              the tests. The project is creation of a preparation module that's not only easy to 
              access but also effective in helping users grasp the various aspects of 
              sustainability and climate risk management.
            </p>
            <ul class="">
              <li><i class="ri-check-double-line"></i>Providing Learning Resources</li>
              <li><i class="ri-check-double-line"></i>Access to Test Series & Mock Tests </li>
              
              

            </ul>
          </div>
          
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Counts Section ======= -->
    

    <!-- ======= About Video Section ======= -->
    

    <!-- ======= Clients Section ======= -->
    

          

    <!-- ======= Services Section ======= -->
    
            
              
            
            
          

          

          
            
          

    

    <!-- ======= Cta Section ======= -->
    

    <!-- ======= Pricing Section ======= -->
    
          
        
                
              
              
                
              
     

    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Frequently Asked Questions</h2>
          
        </div>

        <div class="faq-list">
          <ul>
            <li data-aos="fade-up" >
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-1" class="collapsed" >Is it only free for one day? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-1" class="collapse " data-bs-parent=".faq-list">
                <p>
                  Yes, it is free for only one day after registeration. But you can ask for more free trials.
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="100">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-2" class="collapsed">After payment how many days I can access? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-2" class="collapse" data-bs-parent=".faq-list">
                <p>
                  You can access it anytime, anywhere after payment.
                </p>
              </div>
            </li>



          </ul>
        </div>

      </div>
    </section><!-- End Frequently Asked Questions Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Contact</h2>
          
        </div>

        

        <div class="row">

          

          

          <div class="col-lg-12  mt-lg-0">

            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="row gy-2 gx-md-3">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col-md-6 form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
                <div class="form-group col-12">
                  <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
                </div>
                <div class="form-group col-12">
                  <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
                </div>
                <div class="my-3 col-12">
                  <div class="loading">Loading</div>
                  <div class="error-message"></div>
                  <div class="sent-message">Your message has been sent. Thank you!</div>
                </div>
                <div class="text-center col-12"><button type="submit">Send Message</button></div>
              </div>
            </form>

          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

   
      <h2 class="text-center pt-3">
        <a href="#"><i class="bi bi-facebook m-2"></i></a>
        <a href="#"><i class="bi bi-instagram m-2"></i></a>
        <a href="#"><i class="bi bi-twitter-x m-2"></i></a>
        <a href="#"><i class="bi bi-linkedin m-2"></i></a>
  
      </h2>
  

      <div class="me-md-auto text-center text-md-start m-4">
        <div class="copyright text-center">
          &copy; Copyright 2024 <strong><span>SCR</span></strong>. All Rights Reserved
        </div>
        
     
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="js/main.js"></script>

</body>

</html><?php /**PATH C:\laravel-projects\scr\resources\views/welcome.blade.php ENDPATH**/ ?>