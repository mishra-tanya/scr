<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SCR: Add Questions</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
    <?php echo $__env->make('admin.admin_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <br><br><br>
   
    <div class="container my-4">
        <b><h2 class="text-center mb-3"><b>Add Questions</b></h2></b>
        
        <div class="row d-flex justify-content-center">
            <div class="col-10 col-md-10 mb-4 ">
                <div class="text-center mt-3 text-dark">
                    <a href="#scr" class="text-dark mx-2" >Add SCR Test Questions</a>
                    <a href="#mock_q" class="text-dark mx-2" >Add SCR Mock Questions</a>
                    <a href="#learning_obj" class="text-dark mx-2">Add Learning Objectives Questions</a>
                </div>
            </div>
            <!-- SCR Questions Form -->
            <div class="col-12 col-md-10 mb-4 " id="scr"style="">
                <div class="container p-4 border shadow-md" style="background-color: rgba(113, 191, 255, 0.279);">
                    <form action="<?php echo e(route('questions.scr.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if(session('success')): ?>
                        <script>
                            alert("<?php echo e(session('success')); ?>");
                        </script>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                        <h3><b>Add SCR Questions</b></h3><hr>
                        <div class="row">
                            <div class="col-12 col-md-4 mb-3">
                                <label for="chapter_id" class="form-label">Chapter</label>
                                <select name="chapter_id" id="chapter_id" class="form-select">
                                    <option value="">Select Chapter</option>
                                    <?php for($i = 1; $i <= 8; $i++): ?>
                                        <option value="<?php echo e($i); ?>">Chapter <?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                                
                            </div>
                            <div class="col-12 col-md-4 mb-3">
                                <label for="test_series" class="form-label">Test Series</label>
                                <select name="test_series" id="test_series" class="form-select">
                                    <option value="">Select Test Series</option>
                                    <?php for($j = 1; $j <= 3; $j++): ?>
                                        <option value="<?php echo e($j); ?>">Test Series <?php echo e($j); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="col-12 col-md-4 mb-3">
                                <label for="result_ans" class="form-label">Correct Answer</label>
                                <select name="result_ans" id="result_ans" class="form-select">
                                    <option value="">Select Correct Answer</option>
                                    <option value="A">A</option>
                                    <option value="B">B</option>
                                    <option value="C">C</option>
                                    <option value="D">D</option>
                                </select>
                            </div>
                            <div class="mb-3 col-12 col-md-6">
                                <label for="question_title" class="form-label">Question</label>
                                <textarea name="question_title" class="form-control" id="question_title"></textarea>
                            </div>
                            <div class="mb-3 col-12 col-md-6">
                                <label for="reason" class="form-label">Reason</label>
                                <textarea type="text" name="reason" class="form-control" id="reason"></textarea>
                            </div>
                            <div class="col-12 col-md-6 mb-3">
                                <label for="option_a" class="form-label">Option A</label>
                                <input type="text" name="option_a" class="form-control" id="option_a">
                            </div>
                            <div class="col-12 col-md-6 mb-3">
                                <label for="option_b" class="form-label">Option B</label>
                                <input type="text" name="option_b" class="form-control" id="option_b">
                            </div>
                            <div class="col-12 col-md-6 mb-3">
                                <label for="option_c" class="form-label">Option C</label>
                                <input type="text" name="option_c" class="form-control" id="option_c">
                            </div>
                            <div class="col-12 col-md-6 mb-3">
                                <label for="option_d" class="form-label">Option D</label>
                                <input type="text" name="option_d" class="form-control" id="option_d">
                            </div>
                        </div>
                        <button type="submit" style="background-color:#2487ce;padding:8px;border:none;width:100%;margin-top:20px;"
                    onmouseover="this.style.backgroundColor='#1a5f90'" 
                    onmouseout="this.style.backgroundColor='#2487ce'"
                    class="text-light">Add SCR Question</button>
                    </form>
                </div>
            </div>
            <br>
            <hr><br>
            <!-- SCR Mock Questions Form -->
            <div class="col-12 col-md-10 mb-4"id="mock_q">
                <div class="container p-4 border shadow-md" style="background-color: rgba(113, 191, 255, 0.279);">
                   <form action="<?php echo e(route('questions.mock.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <h3><b>Add SCR Mock Questions</b></h3><hr>
                    <div class="row">
                        <div class="col-12 col-md-4 mb-3">
                            <label for="chapter_id" class="form-label">Chapter</label>
                            <select name="chapter_id" id="chapter_id" class="form-select">
                                <option value="">Select Chapter</option>
                                <?php for($i = 1; $i <= 10; $i++): ?>
                                    <option value="<?php echo e($i); ?>">Chapter <?php echo e($i); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-12 col-md-4 mb-3">
                            <label for="test_series" class="form-label">Mock Series</label>
                            <select name="test_series" id="test_series" class="form-select">
                                <option value="">Select Mock Series</option>
                                <?php for($j = 1; $j <= 5; $j++): ?>
                                    <option value="<?php echo e($j); ?>">Mock Test <?php echo e($j); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-12 col-md-4 mb-3">
                            <label for="result_ans" class="form-label">Correct Answer</label>
                            <select name="result_ans" id="result_ans" class="form-select">
                                <option value="">Select Correct Answer</option>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                            </select>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label for="question_title" class="form-label">Question</label>
                            <textarea name="question_title" class="form-control" id="question_title"></textarea>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label for="reason" class="form-label">Reason</label>
                            <textarea type="text" name="reason" class="form-control" id="reason"></textarea>
                        </div>
                        <div class="col-12 col-md-6 mb-3">
                            <label for="option_a" class="form-label">Option A</label>
                            <input type="text" name="option_a" class="form-control" id="option_a">
                        </div>
                        <div class="col-12 col-md-6 mb-3">
                            <label for="option_b" class="form-label">Option B</label>
                            <input type="text" name="option_b" class="form-control" id="option_b">
                        </div>
                        <div class="col-12 col-md-6 mb-3">
                            <label for="option_c" class="form-label">Option C</label>
                            <input type="text" name="option_c" class="form-control" id="option_c">
                        </div>
                        <div class="col-12 col-md-6 mb-3">
                            <label for="option_d" class="form-label">Option D</label>
                            <input type="text" name="option_d" class="form-control" id="option_d">
                        </div>
                    </div>
                    <button type="submit" style="background-color:#2487ce;padding:8px;border:none;width:100%;margin-top:20px;"
                    onmouseover="this.style.backgroundColor='#1a5f90'" 
                    onmouseout="this.style.backgroundColor='#2487ce'"
                    class="text-light">Add SCR Mock Question</button>
                </div>
            </div>
            <br><hr><br></form>
            <!-- Learning Objective Questions Form -->
            <div class="col-12 col-md-10 mb-4 "style=""id="learning_obj">
                <div class="container p-4 border shadow-md" style="background-color: rgba(113, 191, 255, 0.279);">
                    <form action="<?php echo e(route('questions.lo.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <h3><b>Add Learning Objective Questions</b></h3><hr>
                        <div class="row">
                            <div class="col-12 col-md-4 mb-3">
                                <label for="chapter_id" class="form-label">Chapter</label>
                                <select name="chapter_id" id="lo_chapter_id" class="form-select">
                                    <option value="">Select Chapter</option>
                                    <?php for($i = 1; $i <= 10; $i++): ?>
                                        <option value="<?php echo e($i); ?>">Chapter <?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="col-12 col-md-4 mb-3">
                                <label for="learning_objective" class="form-label">Learning Objective</label>

                                <select name="learning_objective" id="learning_objective" class="form-select">
                                    <option value="">Select Learning Objective</option>
                                    
                                </select>
                            </div>
                            <div class="col-12 col-md-4 mb-3">
                                <label for="result_ans" class="form-label">Correct Answer</label>
                                <select name="result_ans" id="result_ans" class="form-select">
                                    <option value="">Select Correct Answer</option>
                                    <option value="A">A</option>
                                    <option value="B">B</option>
                                    <option value="C">C</option>
                                    <option value="D">D</option>
                                </select>
                            </div>
                            <div class="col-12 col-md-6 mb-3">
                                <label for="question_title" class="form-label">Question</label>
                                <textarea name="question_title" class="form-control" id="question_title"></textarea>
                            </div>
                            <div class="col-12 col-md-6 mb-3">
                                <label for="reason" class="form-label">Reason</label>
                                <textarea type="text" name="reason" class="form-control" id="reason"></textarea>
                            </div>
                            <div class="col-12 col-md-6 mb-3">
                                <label for="option_a" class="form-label">Option A</label>
                                <input type="text" name="option_a" class="form-control" id="option_a">
                            </div>
                            <div class="col-12 col-md-6 mb-3">
                                <label for="option_b" class="form-label">Option B</label>
                                <input type="text" name="option_b" class="form-control" id="option_b">
                            </div>
                            <div class="col-12 col-md-6 mb-3">
                                <label for="option_c" class="form-label">Option C</label>
                                <input type="text" name="option_c" class="form-control" id="option_c">
                            </div>
                            <div class="col-12 col-md-6 mb-3">
                                <label for="option_d" class="form-label">Option D</label>
                                <input type="text" name="option_d" class="form-control" id="option_d">
                            </div>
                           
                           
                        </div>
                        <button type="submit" style="background-color:#2487ce;padding:8px;border:none;width:100%;margin-top:20px;"
                    onmouseover="this.style.backgroundColor='#1a5f90'" 
                    onmouseout="this.style.backgroundColor='#2487ce'"
                    class="text-light">Add Learning Objective</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Success Modal -->
    
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // JavaScript
        document.addEventListener('DOMContentLoaded', function() {
            const chapterSelect = document.getElementById('lo_chapter_id');
            const learningObjectiveSelect = document.getElementById('learning_objective');
            console.log(chapterSelect)
            console.log(learningObjectiveSelect)

            chapterSelect.addEventListener('change', function() {
                console.log('Chapter selection changed');
                const chapterId = this.value;
                console.log("chaptter du"+chapterId)
                if (!chapterId) return; 
    
                fetch('/admin/fetch-learning-objectives/' + chapterId)
                .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to fetch learning objectives');
                }
                return response.json();
            })
                    .then(data => {
                        console.log(learningObjectiveSelect)
                        learningObjectiveSelect.innerHTML = '<option value="">Select Learning Objective</option>';
                        data.forEach((obj, index) => {
                            const option = document.createElement('option');
                            option.value = obj.url_id;
                            option.textContent = index+1 +". " +obj.title;
                            learningObjectiveSelect.appendChild(option);
                        });
                    })
                    .catch(error => {
                        console.error('Error fetching learning objectives:', error);
                    });
            });
        });
    </script>
</body>
</html>
<?php /**PATH C:\laravel-projects\scr\resources\views/admin/add_questions.blade.php ENDPATH**/ ?>