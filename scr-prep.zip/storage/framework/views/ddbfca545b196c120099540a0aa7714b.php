<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SCR Test Results</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        .quiz-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            /* border: 1px solid #ccc; */
            border-radius: 5px;
        }

        .card-container {
            max-width: 600px;
            margin: 0 auto;
            margin-top: 20px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .question {
            margin-bottom: 20px;
            border: 2px black solid;
            padding: 20px;
        }

        .options {
            font-size: 20px;
        }

        .option {
            margin-right: 10px;
            margin-bottom: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            cursor: pointer;
        }

        .option.selected {
            background-color: lightblue;
        }

        .correct {
            background-color: green;
            color: white;
            border: 5px double rgb(211, 211, 211);
        }

        .incorrect {
            background-color: #f44949;
            color: white;
            border: 5px double rgb(211, 211, 211);

        }

        .ya {
            padding: 10px;
            border-radius: 5px;
            color: white;
            border: 5px double rgb(211, 211, 211);

        }

        .ca {
            padding: 10px;
            background-color: green;
            border-radius: 5px;
            color: white;
            border: 5px double rgb(211, 211, 211);

        }

        .result {
            padding: 20px;
        }

        .correct-answer {
            display: inline-block;
            margin-top: 15px;
            font-size: 18px;
        }

        .number-line {
            display: flex;
            justify-content: center;
            margin: 20px;
            flex-wrap: wrap;
        }

        .number-line .number {
            margin: 5px;
            padding: 10px;
            border: 4px double rgb(211, 211, 211);
            ;
            border-radius: 20%;
            width: 40px;
            height: 40px;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
        }

        .number-line .number.correct {
            background-color: green;
            color: white;
        }

        .number-line .number.incorrect {
            background-color: red;
            color: white;
        }

        .number-line .number.not-attempted {
            background-color: gray;
            color: white;
        }

        .question {
            margin-bottom: 20px;
            border: 2px black solid;
            padding: 20px;
            display: none;
        }

        .question.active {
            display: block;
        }
        .question-number-list button.reviewed {
            background-color: #826201;
        }

        @media(max-width:765px) {
            .card-container {
                max-width: 600px;
                margin: 20px;
                margin-top: 20px;
                padding: 20px;
                border: 1px solid #ccc;
                border-radius: 5px;

            }

            h2 {
                font-size: 30px;
                font-weight: bold;
            }

        }
    </style>
    <link rel="stylesheet" href="../../css/graph.css">
</head>

<body>
    <?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <br><br>
    <br><br>
    <div class="text-center">
        <?php if(is_numeric($chapter_id)): ?>
            <h2><b>Mock Test: <?php echo e($chapter_id); ?></b><span class="d-none d-md-inline"></span></h2>
        <?php else: ?>
            <?php if(preg_match('/[A-Za-z][0-9][A-Za-z][0-9]/', $chapter_id)): ?>
                <h2><b>Chapter: <?php echo e(substr($chapter_id, 1, 1)); ?></b><span
                        class="d-none d-md-inline">&nbsp;&nbsp;&nbsp;</span>
                    <b class="d-block d-md-inline">Test Series: <?php echo e(substr($chapter_id, 3, 1)); ?></b>
                </h2>
            <?php else: ?>
                <h2><b>Invalid Chapter ID: <?php echo e($chapter_id); ?></b></h2>
            <?php endif; ?>
        <?php endif; ?>

        
    </div> <br>
    <h2 class="text-center"><b>Your Result</b></h2>

    <div class="card-container">
        <div class="card-div">
            <div class="">
                <?php
                    $percentage = 0;
                    $remark = '';

                    if ($totalQuestions > 0) {
                        $percentage = ($correctAnswers / $totalQuestions) * 100;

                        if ($percentage >= 90) {
                            $remark = 'Excellent!';
                        } elseif ($percentage >= 75) {
                            $remark = 'Good job!';
                        } elseif ($percentage >= 50) {
                            $remark = 'Not bad!';
                        } else {
                            $remark = 'Keep practicing!';
                        }
                    } else {
                        $remark = 'Give the test first to see the result!!';
                    }
                ?>



                <h4 class="text-center"><strong> <?php echo e($remark); ?></strong></h4>
                <div class="row">
                    <?php if($totalQuestions > 0): ?>
                        <div class="col-lg-6 col-md-12 text-end">
                            <div
                                class="card-body d-flex flex-column justify-content-center align-items-center text-center">
                                <svg viewBox="0 0 36 36" class="circular-chart">
                                    <path class="circle-bg" d="M18 2.0845
                                    a 15.9155 15.9155 0 0 1 0 31.831
                                    a 15.9155 15.9155 0 0 1 0 -31.831" />
                                    <path id="circle" class="circle"
                                        stroke-dasharray="
                                    <?php echo e(($correctAnswers / $totalQuestions) * 100); ?>

                                    
                                    , 100"
                                        d="M18 2.0845
                                    a 15.9155 15.9155 0 0 1 0 31.831
                                    a 15.9155 15.9155 0 0 1 0 -31.831" />
                                    <text x="18" y="20.35" class="percentage"><?php echo e($correctAnswers); ?>

                                        / <?php echo e($totalQuestions); ?></text>
                                </svg>

                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="result">
                    <?php if($totalQuestions > 0): ?>
                        <p><strong>Total Questions:</strong> <?php echo e($totalQuestions); ?></p>
                        <p><strong>Correct Answers:</strong> <?php echo e($correctAnswers); ?></p>
                        <p><strong>Incorrect Answers:</strong> <?php echo e($totalQuestions - $correctAnswers); ?></p>
                        <p><strong>Percentage:</strong>
                            <?php echo e(number_format(($correctAnswers / $totalQuestions) * 100, 2)); ?>%
                    <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>

    <br>
    <div class="number-line">
        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $numberClass = '';
                if ($question['user_answer'] == '') {
                    $numberClass = 'not-attempted';
                } elseif ($question['user_answer'] == $question['correct_answer']) {
                    $numberClass = 'correct';
                } else {
                    $numberClass = 'incorrect';
                }
            ?>
            <div class="number <?php echo e($numberClass); ?>" data-target="#question-<?php echo e($index + 1); ?>"><?php echo e($index + 1); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="quiz-container">
        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="question-<?php echo e($index + 1); ?>" class="question <?php if($index == 0): ?> active <?php endif; ?> shadow-lg">
            <b>
                    <h4><strong>Question <?php echo e($index + 1); ?>:</strong></h4>
                </b>
                <h4 class="mb-3"><b><?php echo e($question['question_title']); ?></b></h4>
                <div class="options">
                    <div
                        class="option <?php if($question['user_answer'] == 'A'): ?> <?php if($question['user_answer'] == $question['correct_answer']): ?> correct <?php else: ?> incorrect <?php endif; ?> <?php endif; ?>">
                        <b>A:</b> <?php echo e($question['option_a']); ?>

                    </div>
                    <div
                        class="option <?php if($question['user_answer'] == 'B'): ?> <?php if($question['user_answer'] == $question['correct_answer']): ?> correct <?php else: ?> incorrect <?php endif; ?> <?php endif; ?>">
                        <b>B:</b> <?php echo e($question['option_b']); ?>

                    </div>
                    <div
                        class="option <?php if($question['user_answer'] == 'C'): ?> <?php if($question['user_answer'] == $question['correct_answer']): ?> correct <?php else: ?> incorrect <?php endif; ?> <?php endif; ?>">
                        <b>C:</b> <?php echo e($question['option_c']); ?>

                    </div>
                    <div
                        class="option <?php if($question['user_answer'] == 'D'): ?> <?php if($question['user_answer'] == $question['correct_answer']): ?> correct <?php else: ?> incorrect <?php endif; ?> <?php endif; ?>">
                        <b>D:</b> <?php echo e($question['option_d']); ?>

                    </div>
                </div><br>
                <?php if($question['user_answer'] == ''): ?>
                    <span class="ya incorrect"><strong>Your Answer:</strong> Not Attempted</span>
                <?php else: ?>
                    <span class="ya <?php if($question['user_answer'] == $question['correct_answer']): ?> correct <?php else: ?> incorrect <?php endif; ?>"><strong>Your
                            Answer:</strong> <?php echo e($question['user_answer']); ?></span>
                <?php endif; ?>

                <div class=" d-sm-none">
                    <p class="correct-answer ca"style="width:auto;margin-top:15px; font-size:18px;"><strong
                            class="">Correct Answer:</strong> <?php echo e($question['correct_answer']); ?></p>
                </div>
                <span class="ca d-none d-sm-inline">
                    <strong>Correct Answer:</strong> <?php echo e($question['correct_answer']); ?>

                </span>
                <p><strong><br>Reason:</strong> <?php echo e($question['reason']); ?></p>
                <style>
                      .button {
                    width: 200px;
                    height: 50px;
                    border: 5px double rgb(211, 211, 211);
                    border-radius: 5px;
                    font-size: 18px;
                }
                #next {
                    background-color: #0056b3;
                    color: white;
                }
                </style>
                <div style="display: flex; justify-content: end;">
                    <button id="next" class="button next-button" data-next="<?php echo e($index + 2); ?>">Next</button>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
<br><br><hr>
    </div>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            let currentQuestionIndex = 0;
            const questions = document.querySelectorAll('.question');
            const nextButtons = document.querySelectorAll('.next-button');
    
            nextButtons.forEach((button, index) => {
                button.addEventListener('click', function () {
                    questions[currentQuestionIndex].classList.remove('active');
                    if (index + 1 < questions.length) {
                        questions[index + 1].classList.add('active');
                        currentQuestionIndex = index + 1;
                    }
                });
            });
    
            document.querySelectorAll('.number-line .number').forEach(number => {
                number.addEventListener('click', function () {
                    questions[currentQuestionIndex].classList.remove('active');
                    currentQuestionIndex = parseInt(this.textContent) - 1;
                    questions[currentQuestionIndex].classList.add('active');
                });
            });
        });
    </script>
    
    <script>
        document.querySelectorAll('.number-line .number').forEach(number => {
            number.addEventListener('click', function() {
                document.querySelector(this.dataset.target).scrollIntoView({
                    behavior: 'smooth'
                });
                document.querySelectorAll('.number-line .number').forEach(num => num.classList.remove(
                    'active'));
                this.classList.add('active');
            });
        });
        
    </script>
</body>

</html>
<?php /**PATH C:\laravel-projects\scr\resources\views/users/series/results.blade.php ENDPATH**/ ?>