<style>
.footer{
    background-color:rgb(241, 241, 241);
    padding-bottom: 10px;
}
.bi{
    color: #2487ce;
}
</style>
<div class="footer">
    <h2 class="text-center pt-3">
        <a href="#"><i class="bi bi-facebook m-2"></i></a>
        <a href="#"><i class="bi bi-instagram m-2"></i></a>
        <a href="#"><i class="bi bi-linkedin m-2"></i></a>
      </h2>
    
      <div class="me-md-auto text-center text-md-start m-4">
        <div class="copyright text-center">
          &copy; Copyright 2024 <strong><span>SCR</span></strong>. All Rights Reserved
        </div>
    </div>
</div><?php /**PATH C:\laravel-projects\scr\resources\views/footer.blade.php ENDPATH**/ ?>