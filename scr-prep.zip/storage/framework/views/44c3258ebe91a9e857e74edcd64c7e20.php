<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">
    <title>Learning Objective Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <!-- Boxicons CDN Link -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f5f5f5;
            padding-top: 20px;
        }

        .card {
            padding: 15px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            transition: transform 0.3s ease;
            width: 100%;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-content {
            padding: 20px;
        }

        .card-label {
            font-weight: bold;
            color: #555;
        }

        .card-value {
            color: #333;
        }

        .custom-btn {
            background-color: #2487ce;
            color: #fff;
            width: 100%;
            border: none;
            font-size: 13px;
            border-radius: 0;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .custom-btn:hover {
            background-color: #0095b3;
        }

        hr {
            border: 1px solid rgb(0, 0, 0);
            border-radius: 100%;
            border-top: 1px dotted #000000;
        }

        @media (max-width: 920px) {
            .custom-btn {
                width: 100%;
            }
            .card-content {
            padding: 10px;
        }
        }
    </style>
</head>

<body>
    <?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <br>
    <div class="mt-4">
        <h2 class="text-center mb-4" style="background-color: rgb(235, 235, 235); padding: 12px;">
            Learning Objective Test
        </h2>
    </div>

    <div class="container mt-4">
        <div class="row">
            <div class="col-12 mb-3">
                
                    <div class="card-content"> 
                        <?php $__currentLoopData = $testNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter => $tests): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mb-4">
                            <div class="card-content">
                                <h2 class="text-center"><b>Lesson: <?php echo e($chapter_id=substr($chapter,2)); ?></b></h2>
                                <hr>
                                <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card-item row">
                                    <div class="col-12 col-md-10">
                                        <div class="card-label">
                                            <p><?php echo e($index+1); ?>. <?php echo e($test->title); ?></p>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-2 text-end">
                                        <div class="card-value text-end">
                                            <?php
                                            $test_url_id = $test->url_id;
                                            $ch= "lo_test".substr($chapter,2);

                                            $isAttempted = false;
                                            foreach ($attemptedTests as $attemptedTest) {
                                                // dd($attemptedTest);
                                                if ($ch == $attemptedTest['test'] && $test_url_id == $attemptedTest['chapter_id']) {
                                                    $isAttempted = true;
                                                    break;
                                                }
                                            }
                                        ?>
                                
                                        <?php if($isAttempted): ?>
                                            <button class="btn text-center custom-btn btn-block" disabled>Attempted</button>
                                        <?php else: ?>
                                            <a href="questions/<?php echo e($test_url_id); ?>/lo_test<?php echo e($chapter_id); ?>" class="btn text-capitalize custom-btn btn-block">Unattempted</a>
                                        <?php endif; ?>
                                            
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                
            </div>
        </div>
    </div>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <br>
    <script>
        window.addEventListener('pageshow', function(event) {
            if (event.persisted) {
                window.location.reload();
            }
        });
    </script>
</body>

</html>
<?php /**PATH C:\laravel-projects\scr\resources\views/users/series/learning_obj.blade.php ENDPATH**/ ?>