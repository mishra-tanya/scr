<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">

    <style>
        table th {
            background: #2487ce !important;
            color: white !important;
            text-align: center;
            vertical-align: middle;
        }
    </style>
</head>

<body>
    <?php echo $__env->make('admin/admin_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br><br>
<br>
<div class="m-4 border shadow-md">
    <h2 class="text-center " style="background-color: rgb(255, 255, 255); padding: 12px;">All Admins
    </h2>
    <div class="container">
        <div class="panel">
            <div class="table-responsive">
                <table id="all_admin" class="table table-hover  text-center table-bordered table-condensed">
                    <thead style="">
                        <tr>
                            <th>S.No.</th>
                            <th>Admin Name</th>
                            <th>Admin Email</th>
                            <th>Admin Address</th>
                            <th>Admin Contact</th>
                            <th>Country</th>
                            <th>Designation</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td class="text-capitalize"><?php echo e($admin->first_name." ".$admin->last_name); ?></td>
                                <td><?php echo e($admin->email); ?></td>
                                <td class="text-capitalize"><?php echo e($admin->address); ?></td>
                                <td></td>
                                <td class="text-capitalize"><?php echo e($admin->country); ?></td>
                                <td class="text-capitalize"><?php echo e($admin->designation); ?></td>
                                
                                
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div><br><br>


    <div class="m-4 border shadow-md">
        <h2 class="text-center " style="background-color: rgb(255, 255, 255); padding: 12px;">All Users
        </h2>
        <div class="container">
            <div class="panel">
                <div class="table-responsive">
                    <table id="all_user" class="table table-hover  text-center table-bordered table-condensed">
                        <thead style="">
                            <tr>
                                <th>S.No.</th>
                                <th>User Name</th>
                                <th>User Email</th>
                                <th>User Contact</th>
                                <th>User Address</th>
                                <th>Country</th>
                                <th>Designation</th>
                                <th>Overall Scr Result</th>
                                <th>Overall Learning Obj Result</th>
                                <th>Payment Status</th>
                                <th>Trial Days</th>
                                <th>View</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td class="text-capitalize"><?php echo e($user->first_name." ".$user->last_name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->contact_no); ?></td>
                                    <td class="text-capitalize"><?php echo e($user->address); ?></td>
                                    <td class="text-capitalize"><?php echo e($user->country); ?></td>
                                    <td class="text-capitalize"><?php echo e($user->designation); ?></td>
                                    <td><?php echo e($user->scr); ?> %</td>
                                    <td><?php echo e($user->learning_obj); ?> %</td>
                                    <td><?php if($user->payment_status==1): ?>
                                        Paid
                                    <?php else: ?>
                                        Unpaid
                                    <?php endif; ?></td>
                                    <td><?php echo e($user->trial_days); ?></td>
                                    <td><a href="<?php echo e(url('/admin/user/' . $user->email)); ?>">View</a></td>
                                    
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div><br><br>

   
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>

    <script>
        $(document).ready(function() {
          
            $('#all_user').DataTable({
                "order": [
                    [0, "desc"]
                ]
            });

             
            $('#all_admin').DataTable({
                "order": [
                    [0, "desc"]
                ]
            });
        });
    </script>
</body>

</html>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH C:\laravel-projects\scr\resources\views/admin/user_admin.blade.php ENDPATH**/ ?>