<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<style>
     table th{
          background: #2487ce !important;
            color: white !important;
            text-align: center;
            vertical-align: middle;
        }
</style>
</head>

<body>
    <?php echo $__env->make('admin/admin_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <br><br>
    <div class="container mt-4"><br><br>
        <h2 class="text-center text-capitalize" style="text-decoration: underline"><b><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></b>
        </h2>
        <?php if(Session::has('email_success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('email_success')); ?>

        </div>
        <?php endif; ?>
        <br>
        <div class="card mb-4">
            <div class="card-header"style="font-size: 30px;"><i class="bi bi-person-circle"></i> User Information</div>
            <div class="card-body">

                <div class="row">
                    <div class="col-4">
                        <p class="text-capitalize"><strong>User Name: </strong> <?php echo e($user->first_name); ?>

                            <?php echo e($user->last_name); ?></p>
                    </div>
                    <div class="col-4">
                        <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
                    </div>
                    <div class="col-4">
                        <p class="text-capitalize"><strong>Contact:</strong> <?php echo e($user->contact_no); ?></p>
                    </div>
                    <div class="col-4">
                        <p class="text-capitalize"><strong>Address:</strong> <?php echo e($user->address); ?></p>
                    </div>
                    <div class="col-4">
                        <p class="text-capitalize"><strong>Country:</strong> <?php echo e($user->country); ?></p>
                    </div>
                    <div class="col-4">
                        <p class="text-capitalize"><strong>Designation:</strong> <?php echo e($user->designation); ?></p>

                    </div>
                    <div class="col-4">
                        <p><strong>Overall Scr Result:</strong> <?php echo e($user->scr); ?> %</p>

                    </div>
                    <div class="col-4">
                        <p><strong>Overall Learning Obj Result:</strong> <?php echo e($user->learning_obj); ?> %</p>

                    </div>
                    <div class="col-4">
                        <p><strong>Payment Status:</strong>
                            <?php if($user->payment_status == 1): ?>
                                Paid
                            <?php else: ?>
                                Unpaid
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="col-4">
                        <?php if($user->payment_status == 0): ?>
                        <p><strong>Trial Days:</strong> <?php echo e($user->trial_days); ?></p>
                    <?php endif; ?>
                        

                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-header" style="font-size: 30px;"><i class="bi bi-pencil-square"></i> Learning Objective Results</div>
            <div class="card-body">
                <?php if($loResults->isEmpty()): ?>
                    <p>No learning objective results found.</p>
                <?php else: ?>
                    <table id="lo" class="table table-bordered text-center">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>Chapter</th>
                                <th>Learning Objective</th>
                                <th>Correct Questions</th>
                                <th>Total Questions</th>
                                <th>Score</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $loResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i + 1); ?></td>
                                    <td>Chapter <?php echo e(substr($result->test, 7)); ?></td>
                                    <td>Learning Objective <?php echo e(substr($result->chapter_id, 3)); ?></td>
                                    <td><?php echo e($result->score); ?></td>
                                    <td><?php echo e($result->total_q); ?></td>
                                    <td><?php echo e($result->score/$result->total_q *100); ?> %</td>
                                    <td><?php echo e($result->created_at->format('Y-m-d')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-header"style="font-size: 30px;"><i class="bi bi-pencil-square"></i> SCR Results</div>
            <div class="card-body">
                <?php if($results->isEmpty()): ?>
                    <p>No results found.</p>
                <?php else: ?>
                    <table class="table table-bordered text-center" id="scr">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Chapter</th>
                                <th>Test</th>
                                <th>Correct Questions</th>
                                <th>Total Quuestions</th>
                                <th>Score</th>
                                <th>Date</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i + 1); ?></td>
                                    <?php if(is_numeric($result->chapter_id)): ?>
                                        <td> Mock Test</td>
                                        <td>Mock Test <?php echo e($result->chapter_id); ?></td>
                                    <?php else: ?>
                                        <td>Chapter <?php echo e(substr($result->chapter_id, 1, 1)); ?></td>
                                        <td> Test Series <?php echo e(substr($result->chapter_id, 3, 1)); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($result->score); ?> </td>
                                    <td><?php echo e($result->total_question); ?></td>
                                    <td><?php echo e(number_format($result->score / $result->total_question * 100, 1)); ?> %</td>
                                    <td><?php echo e($result->created_at->format('Y-m-d')); ?></td>
                                    
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

<!-- Add a new card for composing and sending emails -->
<div class="card mb-4">
    <div class="card-header"style="font-size: 30px;"><i class="bi bi-envelope"></i> Send Email</div>
    <div class="card-body">
        <form action="<?php echo e(route('admin.send.email', $user->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="subject" class="form-label">Subject</label>
                <input type="text" class="form-control" id="subject" name="subject" required>
            </div>
            <div class="mb-3">
                <label for="message" class="form-label">Message</label>
                <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Send Email</button>
        </form>
    </div>
</div>


    </div>

    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>

    <script>
        $(document).ready(function() {

            $('#lo').DataTable({
                "order": [
                    [0, "desc"]
                ]
            });


            $('#scr').DataTable({
                "order": [
                    [0, "desc"]
                ]
            });
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH C:\laravel-projects\scr\resources\views/admin/user_details.blade.php ENDPATH**/ ?>