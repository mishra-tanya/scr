<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">
    <title>SCR Dashboard </title>
    <link rel="stylesheet" href="style.css">
    <!-- Boxicons CDN Link -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f5f5f5;
            padding-top: 20px;
        }

        .card {
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-content {
            padding: 20px;
        }

        .card-label {
            font-weight: bold;
            color: #555;
        }

        .card-value {
            color: #333;
        }

        .custom-btn {
            background-color: #63a9b7;
            color: #fff;
            width: 61%;
            border: none;
            font-size: 13px;
            border-radius: 70%;
            /* padding: 10px 20px; */
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .custom-btn:hover {
            background-color: #0095b3;
        }

        hr {

            border: 1px solid rgb(0, 0, 0);
            border-radius: 100%;
            border-top: 1px dotted #000000;
        }

        @media (max-width:920px) {
            .custom-btn {
                background-color: #63a9b7;
                color: #fff;
                width: 73%;
                border: none;
                font-size: 13px;
                border-radius: 70%;
                /* padding: 10px 20px; */
                cursor: pointer;
                transition: background-color 0.3s ease;
            }
        }
    </style>
</head>

<body>
    <?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <br>
    <div class=" mt-4">
        <h2 class="text-center mb-4" style="background-color:rgb(235, 235, 235);padding:12px;">SCR Preparation Module
        </h2>
    </div>

    <div class="container mt-4">
        <div class="row">
            <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 mb-3">
                    <div class="card" style="background-color:#E6F7FF">
                        <div class="card-content">
                            <div class="card-item">
                                <div class="row">
                                    <div class="col-12">
                                        <h4 class="card-label"><?php echo e($chapter['title']); ?>:</h4>
                                        <p><?php echo e($chapter['topic']); ?></p>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <?php $__currentLoopData = $chapter['tests']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <form method="POST" action="<?php echo e(route('update-test-status')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="chapter_id" value="<?php echo e($index + 1); ?>">
                                    <input type="hidden" name="link" value="<?php echo e($test['link']); ?>">
                                    <input type="hidden" name="status" value="<?php echo e($test['status']); ?>">
                                    
                                    <input type="hidden" name="testLabel" value="<?php echo e($test['label']); ?>">
                                    <input type="hidden" name="userId" value="<?php echo e(auth()->user()->id); ?>">

                                    <div class="card-item row">
                                        <div class="col-4">
                                            <div class="card-label"><?php echo e($test['label']); ?></div>
                                        </div>
                                        <div class="col-8 text-end">
                                            <div class="card-value text-end">
                                                <button type="submit" 
                                                class="btn text-capitalize custom-btn btn-block <?php if(strtolower($test['status']) === 'attempted'): ?> bg-secondary text-white <?php endif; ?>"
                                                <?php if(strtolower($test['status']) === 'completed'): ?> disabled <?php endif; ?>>
                                            <?php echo e($test['status']); ?>

                                        </button>
                                         </div>
                                        </div>
                                    </div>
                                    <hr>
                                </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>

    <br>
    <div class=" mt-4">
        <h2 class="text-center mb-4" style="background-color:rgb(235, 235, 235);padding:12px;">Complete Mock Tests</h2>
    </div>


    

    <div class="container mt-4 text-center " style="max-width: 1200px;">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-lg-6 col-md-12 mb-3">
                <div class="card" style="max-width:1200px;background-color:#E6F7FF">
                    <div class="card-content">
                        <div class="card-item">
                            <div class="row">
                                <div class="col-12">
                                    <h4 class="card-label">Full Mock Tests</h4>
                                    <p>Complete Mock Tests</p>
                                </div>
                            </div>
                        </div>
                        <?php $__currentLoopData = $mockTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mockTest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form method="POST" action="<?php echo e(route('update-test-status')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="chapter_id" value="<?php echo e($mockTest['chapter_id']); ?>">
                            <input type="hidden" name="link" value="<?php echo e($mockTest['link']); ?>">
                            <input type="hidden" name="status" value="<?php echo e($mockTest['status']); ?>">
                            <input type="hidden" name="testLabel" value="<?php echo e($mockTest['label']); ?>">
                            <input type="hidden" name="userId" value="<?php echo e(auth()->user()->id); ?>">
                    
                            <div class="card-item row">
                                <div class="col-5">
                                    <div class="card-label"><?php echo e($mockTest['label']); ?></div>
                                </div>
                                <div class="col-7 text-end">
                                    <div class="card-value text-end">
                                        <button type="submit" 
                                        class="btn text-capitalize custom-btn btn-block <?php if(strtolower($mockTest['status']) === 'attempted'): ?> bg-secondary text-white <?php endif; ?>"
                                        <?php if(strtolower($mockTest['status']) === 'completed'): ?> disabled <?php endif; ?>>
                                    <?php echo e($mockTest['status']); ?>

                                </button>
                                        </div>
                                </div>
                            </div>
                            <hr>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    

                    </div>
                </div>
            </div>
        </div>

    </div>

    <br>
    <script>
        window.addEventListener('pageshow', function(event) {
            if (event.persisted) {
                window.location.reload();
            }
        });
    </script>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\laravel-projects\scr\resources\views/users/series/scr_questions.blade.php ENDPATH**/ ?>