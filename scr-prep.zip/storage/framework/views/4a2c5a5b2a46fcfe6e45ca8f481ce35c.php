<!DOCTYPE html>
<!-- Created By CodingNepal - www.codingnepalweb.com -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
   <title>SCR Dashboard </title>
    <link rel="stylesheet" href="style.css">
    <!-- Boxicons CDN Link -->
  <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,300italic&subset=latin' rel='stylesheet' type='text/css'>
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="css/home.css">
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <!-- Bootstrap Icons -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    
   </head>
<body>
  <nav>
    <div class="navbar">
      <i class='bx bx-menu'></i>
      <div class="logo"><a href="#">SCR</a></div>
      <div class="nav-links">
        <div class="sidebar-logo">
          <span class="logo-name">SCR</span>
          <i class='bx bx-x' ></i>
        </div>
        <ul class="links">
          <li><a href="/">Home</a></li>
          
          
          <li><a href="/#about">About us</a></li>
          <li><a href="/#contact">Contact us</a></li>
        </ul>
      </div>
      
    </div>
  </nav>

<div>
  <?php echo $__env->make('graph', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <style type="text/css">
    .box_web {
      padding: 15px 15px;
    }
  </style>

  <div class="bred">
    <div class="container">
      <div class="content-header">
        <h1>Dashboard</h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
          <li class="active"><i class="fa fa-dashboard"></i> Dashboard</li>
        </ol>
      </div>
    </div>
  </div>



  <div class="container">
    <div class="box_web">
      <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-12">
          <div class="media-box">

            <div class="media-icon pull-left"><i class="icon-wallet"></i> </div>
            <div class="media-info">
              <h3>SCR</h3>
              <h3>Question Bank</h3>
            </div>
          </a>
          <div class="total_res">
            Total Chapters <span>8</span>
          </div>
          <div class="total_res">
            Total Tests<span>27</span>
          </div>
          <div class="total_res">
            Total Attempted Tests<span></span>
          </div>
          <div class="total_res">
            Total Questions <span>480</span>
          </div>

        </div>

      </div>
 


      <div class="col-lg-4 col-md-4 col-sm-12">
        <div class="media-box bg-blue">
          <a href="#">
            <div class="media-icon pull-left"><i class="icon-edit"></i> </div>
            <div class="media-info">
              <h3>SCR</h3>
              <h3>Revision Notes</h3>
            </div>
          </a>
          <div class="total_res">
            Total Chapters <span>8</span>
          </div>
          <div class="total_res">
            Total Chapters Seen <span></span>
          </div>

          <a href="note"><button style="background: #4ac959; margin-top: 120px;" class="start_now">Start Now</button></a>
        </div>
      </div>

    
      <div class="col-lg-4 col-md-4 col-sm-12">
        <div class="media-box bg-green">
          <a href="#">
            <div class="media-icon pull-left"><i class="icon-layers"></i> </div>
            <div class="media-info">
              <h3>SCR</h3>
              <h3>Revision Flash Card</h3>
            </div>
          </a>
          <div class="total_res">
            Total Chapter<span>8</span>
          </div>
          <div class="total_res">
            Total Chapters Seen <span></span>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>





  <div class="container">
    <div class="box_web">
      <div class="row">
        <div class="col-lg-12" style="overflow: scroll;">
          <table class="web_data">
            <thead>
              <tr>
                <th>User Id</th>
                <th>Test Id</th>
                <!-- <th>Subject</th> -->
                <th>Chapter</th>
                <th>Test</th>

                <th>Status</th>
                <th style="min-width: 170px;">View Response</th>
              </tr>
            </thead>
            <tbody>

       
</div>


  <script src="script.js"></script>
  <script>
// search-box open close js code
let navbar = document.querySelector(".navbar");
// let searchBox = document.querySelector(".search-box .bx-search");
// let searchBoxCancel = document.querySelector(".search-box .bx-x");

// searchBox.addEventListener("click", ()=>{
//   navbar.classList.toggle("showInput");
//   if(navbar.classList.contains("showInput")){
//     searchBox.classList.replace("bx-search" ,"bx-x");
//   }else {
//     searchBox.classList.replace("bx-x" ,"bx-search");
//   }
// });

// sidebar open close js code
let navLinks = document.querySelector(".nav-links");
let menuOpenBtn = document.querySelector(".navbar .bx-menu");
let menuCloseBtn = document.querySelector(".nav-links .bx-x");
menuOpenBtn.onclick = function() {
navLinks.style.left = "0";
}
menuCloseBtn.onclick = function() {
navLinks.style.left = "-100%";
}


// sidebar submenu open close js code
let htmlcssArrow = document.querySelector(".htmlcss-arrow");
htmlcssArrow.onclick = function() {
 navLinks.classList.toggle("show1");
}
let moreArrow = document.querySelector(".more-arrow");
moreArrow.onclick = function() {
 navLinks.classList.toggle("show2");
}
let jsArrow = document.querySelector(".js-arrow");
jsArrow.onclick = function() {
 navLinks.classList.toggle("show3");
}
  </script>
</body>
</html><?php /**PATH C:\laravel-projects\scr\resources\views/home.blade.php ENDPATH**/ ?>