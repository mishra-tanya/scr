<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($subject); ?></title>
</head>
<body>
    <p><?php echo e($message); ?></p>
</body>
</html>
<?php /**PATH C:\laravel-projects\scr\resources\views/admin/email.blade.php ENDPATH**/ ?>